# -*- coding: utf-8 -*-
from setuptools import setup

packages = \
['rem']

package_data = \
{'': ['*']}

install_requires = \
['beautifulsoup4>=4.10.0,<5.0.0',
 'bs4>=0.0.1,<0.0.2',
 'coverage>=6.2,<7.0',
 'google>=3.0.0,<4.0.0',
 'googlemaps>=4.5.3,<5.0.0',
 'pandas>=1.3.4,<2.0.0',
 'pre-commit>=2.15.0,<3.0.0',
 'pytest>=6.2.5,<7.0.0',
 'requests>=2.26.0,<3.0.0',
 'validators>=0.18.2,<0.19.0']

setup_kwargs = {
    'name': 'rem',
    'version': '0.1.3',
    'description': '',
    'long_description': None,
    'author': 'santiagonasar',
    'author_email': 'santiagonasar',
    'maintainer': None,
    'maintainer_email': None,
    'url': None,
    'packages': packages,
    'package_data': package_data,
    'install_requires': install_requires,
    'python_requires': '>=3.9,<4.0',
}


setup(**setup_kwargs)
